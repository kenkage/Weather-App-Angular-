export class Login{
	constructor(public firstName:string,public lastName:string,public mobileNumber:string,public email:string,public password:string,public confirmPassword:string){}
	
}